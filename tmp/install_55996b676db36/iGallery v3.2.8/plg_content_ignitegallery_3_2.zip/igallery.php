<?php
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

class plgContentIgallery extends JPlugin
{
	public function onContentPrepare($context, &$article, &$params, $limitstart)
	{
		$lang =& JFactory::getLanguage();
    	$lang->load('com_igallery', JPATH_ADMINISTRATOR);
		
		$view = JRequest::getCmd('view', null);
		$layout = JRequest::getCmd('layout', null);
	
		JRequest::setVar('view', 'category');
		JRequest::setVar('layout', 'default');
		JRequest::setVar('igsource', 'plugin');
	
		preg_match_all('#\{igallery(.*?)\}#ism',$article->text, $matches);
	
		foreach( $matches[1] as $pluginParams )
		{
			(preg_match('#.*?\sid=([0-9]+).*?#is', $pluginParams, $uid))
		       ?   JRequest::setVar('iguniqueid',$uid[1])
		       :   JError::raise(2, 400, 'required id');
	
		    (preg_match('#.*?cid=([0-9]+).*?#is', $pluginParams, $cid))
		       ?   JRequest::setVar('igid',$cid[1])
		       :   JError::raise(2, 400, 'required category');
	
		    (preg_match('#.*?pid=([0-9]+).*?#is', $pluginParams, $pid))
		       ?   JRequest::setVar('igpid',$pid[1])
		       :   JError::raise(2, 400, 'required profile');
	
		    (preg_match('#.*?type=([a-z]+).*?#is', $pluginParams, $type))
		       ?   JRequest::setVar('igtype',$type[1])
		       :   JError::raise(2, 400, 'required type');
	
		    (preg_match('#.*?children=([0-9]+).*?#is', $pluginParams, $children))
		       ?   JRequest::setVar('igchild',$children[1])
		       :   false;
		       
		    (preg_match('#.*?showmenu=([0-9]+).*?#is', $pluginParams, $showmenu))
		       ?   JRequest::setVar('igshowmenu',$showmenu[1])
		       :   false;
	
		    (preg_match('#.*?tags=([0-9a-zA-Z, ]+).*?#is', $pluginParams, $tags))
		       ?   JRequest::setVar('igtags',$tags[1])
		       :   false;
	
		    (preg_match('#.*?limit=([0-9]+).*?#is', $pluginParams, $limit))
		       ?   JRequest::setVar('iglimit',$limit[1])
		       :   false;
	
			require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_igallery'.DS.'defines.php');
	        require_once(IG_COMPONENT.'controller.php');
	
	        
	        $controller = new IgController();
	
			ob_start();
			$controller->execute('display');
			$pluginHtml = ob_get_contents();
			ob_end_clean();
	
			$article->text = str_replace('{igallery'.$pluginParams.'}', $pluginHtml, $article->text);
		}
	
		if($view != null)
		{
			JRequest::setVar('view', $view);
		}
	
		if($layout != null)
		{
			JRequest::setVar('layout', $layout);
		}
	
		return true;
	}
	
}