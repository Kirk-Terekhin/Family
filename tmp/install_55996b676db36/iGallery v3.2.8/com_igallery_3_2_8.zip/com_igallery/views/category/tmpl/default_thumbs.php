<?php defined('_JEXEC') or die('Restricted access'); ?>
<div id="<?php echo $this->thumbsVars->prefix; ?>_thumbs_arrow_wrapper<?php echo $this->uniqueid; ?>" class="<?php echo $this->thumbsVars->prefix; ?>_thumbs_arrow_wrapper">

<?php
if($this->thumbsVars->arrows_up_down == 1)
{
?>
	<div id="<?php echo $this->thumbsVars->prefix; ?>_up_arrow<?php echo $this->uniqueid; ?>" class="<?php echo $this->thumbsVars->prefix; ?>_up_arrow" style="width: <?php echo $this->thumbsVars->thumb_container_width; ?>px;">
		<img src="<?php echo IG_IMAGE_ASSET_PATH; ?>up_arrow.png"  alt="" />
	</div>
	<div class="igallery_clear"></div>
<?php
}
        
$overflow = $this->thumbsVars->thumb_scrollbar == 1 ? ' overflow: auto;' : ' overflow: hidden;';
$height = $this->thumbsVars->thumb_container_height != 0 ? ' height: '.$this->thumbsVars->thumb_container_height.'px;' : '';
?>

	<div id="<?php echo $this->thumbsVars->prefix; ?>_thumb_container<?php echo $this->uniqueid; ?>" class="<?php echo $this->thumbsVars->prefix; ?>_thumb_container" style="width: <?php echo $this->thumbsVars->thumb_container_width; ?>px;<?php echo $overflow.$height; ?>">

		<table id="<?php echo $this->thumbsVars->prefix; ?>_thumb_table<?php echo $this->uniqueid; ?>" class="<?php echo $this->thumbsVars->prefix; ?>_thumb_table" cellpadding="0" cellspacing="0" >
        <?php
        
        $thumbsInRow = $this->thumbsVars->images_per_row == 0 ? count($this->photoList) : $this->thumbsVars->images_per_row;
        $counter = 0;
        
        while( $counter < count($this->photoList) )
        {
            ?>
			<tr>
            <?php
        	for($i=0; $i<$thumbsInRow; $i++)
        	{
        		if( isset($this->photoList[$counter]) )
        		{
        			$row = $this->photoList[$counter];
        			$thumbClass = ($i == 0) ? 'active_thumb' : 'inactive_thumb';
        			?>
        				<td align="center" class="<?php echo $thumbClass; ?>">
        					<div id="<?php echo $this->thumbsVars->prefix; ?>-<?php echo $this->uniqueid; ?>-<?php echo $counter + 1; ?>" class="thumbs_div" style="width: <?php echo $this->thumbsVars->thumb_array[$counter]['width'] + 14; ?>px; height:<?php echo $this->thumbsVars->thumb_array[$counter]['height'] + 14; ?>px;" >
        						<a href="#">
        							<img src="<?php echo IG_IMAGE_HTML_RESIZE ?><?php echo $this->thumbsVars->thumb_array[$counter]['folderName']; ?>/<?php echo $this->thumbsVars->thumb_array[$counter]['fullFileName']; ?>" title="<?php echo $row->alt_text; ?>" alt="<?php echo $row->alt_text; ?>" width="<?php echo $this->thumbsVars->thumb_array[$counter]['width']; ?>" height="<?php echo $this->thumbsVars->thumb_array[$counter]['height']; ?>" />
        						</a>
        					</div>
        					<?php 
			        		$profileValue = $this->thumbsVars->prefix == 'main' ? 'show_thumb_info' : 'lbox_show_thumb_info';
						    $thumbText = '';
						    
			        		switch($this->profile->{$profileValue})
			        		{
							    case 'description':
							        $thumbText = $row->description;
							        break;
							    case 'alt':
							        $thumbText = $row->alt_text;
							        break;
							    case 'full':
							        $thumbText = $row->filename;
							        break;
						        case 'no-id':
							        preg_match_all('/-[0-9]+/', $row->filename, $matches);
	    							$thumbText = str_replace($matches[0][0], '', $row->filename);
						        break;
						        case 'no-ext':
							        $thumbText = str_replace(array('.jpg','.jpeg','.gif','.png'), '', $row->filename);
						        break;
						        case 'no-id-no-ext':
							        preg_match_all('/-[0-9]+/', $row->filename, $matches);
							    	$thumbText = str_replace($matches[0][0], '', $row->filename);
							    	$thumbText = str_replace(array('.jpg','.jpeg','.gif','.png'), '', $thumbText);
						        break;
						        default:
       								$thumbText = '';
			        		}
        					
        					?><span class="<?php echo $this->thumbsVars->prefix; ?>_thumb_text"><?php echo $thumbText; ?></span>
        					
        				</td>
            		<?php
            		}
            		else
            		{
            		?>
        				<td>
        				    &nbsp;
        				</td>
            		<?php
		            }
		            $counter++;
	           }
	           ?>
               </tr>

           <?php
           }
           ?>
		</table>

	</div>

    <?php
    if($this->thumbsVars->arrows_left_right == 1)
    {
        ?>		
        <div class="igallery_clear"></div>
		<div id="<?php echo $this->thumbsVars->prefix; ?>_left_right_arrows_div<?php echo $this->uniqueid; ?>" class="<?php echo $this->thumbsVars->prefix; ?>_left_right_arrows_div" style="width: <?php echo $this->thumbsVars->thumb_container_width; ?>px;">

			<img src="<?php echo IG_IMAGE_ASSET_PATH; ?>left_arrow.png" id="<?php echo $this->thumbsVars->prefix; ?>_left_arrow<?php echo $this->uniqueid; ?>" class="<?php echo $this->thumbsVars->prefix; ?>_left_arrow_img" alt="" />
			<img src="<?php echo IG_IMAGE_ASSET_PATH; ?>right_arrow.png" id="<?php echo $this->thumbsVars->prefix; ?>_right_arrow<?php echo $this->uniqueid; ?>" class="<?php echo $this->thumbsVars->prefix; ?>_right_arrow_img" alt="" />

		</div>
    <?php
    }

    if($this->thumbsVars->arrows_up_down == 1)
    {
    ?>
    	<div class="igallery_clear"></div>
    	<div id="<?php echo $this->thumbsVars->prefix; ?>down_arrow<?php echo $this->uniqueid; ?>" class="<?php echo $this->thumbsVars->prefix; ?>_down_arrow" style="width: <?php echo $this->thumbsVars->thumb_container_width; ?>px;">
    		<img src="<?php echo IG_IMAGE_ASSET_PATH; ?>down_arrow.png" id="<?php echo $this->thumbsVars->prefix; ?>_down_arrow<?php echo $this->uniqueid; ?>" alt="" />
    	</div>
    <?php
    }
    
    if($this->profile->thumb_pagination == 1 && $this->thumbsVars->prefix == 'main')
    {
    ?>
    <div class="igallery_clear"></div>
    <form action="index.php?option=com_igallery&amp;view=igcategory&amp;id=<?php echo $this->category->id; ?>&amp;Itemid=<?php echo $this->Itemid; ?>" method="post" name="ig_thumb_pagination">   
	<div class="pagination">
		<?php echo $this->thumbPagination->getPagesLinks(); ?>
	</div>
	</form>
	<?php
    }
    ?>
</div>