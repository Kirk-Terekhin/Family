<?php defined('_JEXEC') or die('Restricted access'); ?>

<div id="<?php echo $this->commentsVars->prefix; ?>_fbcomments<?php echo $this->uniqueid; ?>" class="<?php echo $this->commentsVars->prefix; ?>_fbcomments" style="width: <?php echo $this->commentsVars->width; ?>px" >
	
</div>