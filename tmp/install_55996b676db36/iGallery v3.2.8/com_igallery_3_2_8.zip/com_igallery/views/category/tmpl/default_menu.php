<?php defined( '_JEXEC' ) or die( 'Restricted access' ); ?>

<div class="igallery_clear"></div>
<form action="index.php?option=com_igallery&amp;view=category&amp;id=<?php echo $this->category->id; ?>&amp;Itemid=<?php echo $this->Itemid; ?>" method="post" name="ig_menu_pagination">

<?php 
if(count($this->categoryChildren) != 0)
{
	?>
	<div id="cat_child_wrapper<?php echo $this->uniqueid; ?>" class="cat_child_wrapper">
	<?php
	$counter = 0;
	$columns = $this->profile->columns == 0 ? count($this->categoryChildren) : $this->profile->columns;
	
	while( $counter < count($this->categoryChildren) )
	{
		for($i=0; $i<$columns; $i++)
		{
			if( isset($this->categoryChildren[$counter]) )
			{
				$row = $this->categoryChildren[$counter];
			    $link = JRoute::_('index.php?option=com_igallery&amp;view=category&amp;igid='.$row->id.'&amp;Itemid='.$this->Itemid);
				?>
				
				<div class="cat_child" style="width: <?php echo $row->menu_max_width; ?>px;">
					<h3 class="cat_child_h3">
						<a href="<?php echo $link; ?>" class="cat_child_a">
							<?php echo $row->name; ?>
						</a>
					</h3>
					<?php
					if( isset($row->fileArray))
					{
					?>
						<a href="<?php echo $link; ?>">
						   <img src="<?php echo IG_IMAGE_HTML_RESIZE; ?><?php echo $row->fileArray['folderName']; ?>/<?php echo $row->fileArray['fullFileName']; ?>" alt=""/>
						</a>
					<?php
					}
					echo $row->menu_description;
					if($this->profile->show_category_hits == 1)
					{
					?>
					<br /><?php echo JText::_('COM_IGALLERY_VIEWS'); ?>: <?php echo $row->hits; ?>
					<?php	
					}
					?>
				</div>
				<?php
			}
			$counter++;
		}
		?>
		<div class="igallery_clear"></div>
		<?php
	}
?>
</div>
<div class="igallery_clear"></div>
<?php
}
?>

<?php if($this->profile->menu_pagination == 1): ?>    

	<div class="pagination">
		<?php echo $this->menuPagination->getPagesLinks(); ?>
	</div>

	<div class="pagination">
		<?php echo $this->menuPagination->getPagesCounter(); ?>
	</div>

<?php endif; ?>
</form>
<div class="igallery_clear"></div>