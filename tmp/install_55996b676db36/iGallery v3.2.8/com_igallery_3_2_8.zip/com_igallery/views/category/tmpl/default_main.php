<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

if($this->source == 'component' && $this->type == 'category')
{
    echo $this->loadTemplate('header');
}

if($this->source == 'component' && $this->profile->show_search == 1)
{
    echo $this->loadTemplate('search');
}

if($this->profile->gallery_des_position == 'above' && strlen($this->category->gallery_description) > 1 && $this->type == 'category')
{
	echo $this->loadTemplate('category_description');
}

if( count($this->categoryChildren) && $this->showMenu == 1)
{
    echo $this->loadTemplate('menu');
}

if( !empty($this->photoList) )
{

$align = $this->profile->align == 'center' ? 'margin-left: auto; margin-right: auto;' : 'float: '.$this->profile->align;
?>
<div id="main_images_wrapper<?php echo $this->uniqueid; ?>" class="main_images_wrapper" style="width: <?php echo $this->dimensions['galleryWidth']; ?>px; <?php echo $align; ?>" >
<?php

$this->thumbsVars = new stdClass();
$this->thumbsVars->thumb_scrollbar = $this->profile->thumb_scrollbar;
$this->thumbsVars->images_per_row = $this->profile->images_per_row;
$this->thumbsVars->prefix = 'main';
$this->thumbsVars->arrows_left_right = $this->profile->arrows_left_right;
$this->thumbsVars->arrows_up_down = $this->profile->arrows_up_down;
$this->thumbsVars->thumb_array = $this->thumbFiles;


if($this->profile->thumb_position == 'above' && $this->profile->show_thumbs == 1)
{
	$this->thumbsVars->thumb_container_width = ($this->profile->thumb_container_width == 0) ? $this->dimensions['galleryWidth'] : $this->profile->thumb_container_width;
	$this->thumbsVars->thumb_container_height = $this->profile->thumb_container_height;
	echo $this->loadTemplate('thumbs');
}

$this->desVars = new stdClass();
$this->desVars->prefix = 'main';

if($this->profile->photo_des_position == 'above' && $this->profile->show_descriptions == 1)
{
	$this->desVars->des_container_width = $this->profile->photo_des_width == 0 ? $this->dimensions['galleryWidth'] : $this->profile->photo_des_width;
	$this->desVars->photo_des_height = $this->profile->photo_des_height == 0 ? 50 : $this->profile->photo_des_height;

	echo $this->loadTemplate('descriptions');
}

if($this->profile->photo_des_position == 'left' && $this->profile->show_descriptions == 1)
{
	$this->desVars->des_container_width = $this->profile->photo_des_width == 0 ? 200 : $this->profile->photo_des_width;
	$this->desVars->photo_des_height = $this->profile->photo_des_height == 0 ? $this->dimensions['largestHeight'] : $this->profile->photo_des_height;

	echo $this->loadTemplate('descriptions');
}

if($this->profile->thumb_position == 'left' && $this->profile->show_thumbs == 1)
{
    $this->thumbsVars->thumb_container_width = $this->profile->thumb_container_width;
	$this->thumbsVars->thumb_container_height = $this->profile->thumb_container_height == 0 ? $this->dimensions['largestHeight'] : $this->profile->thumb_container_height;

	echo $this->loadTemplate('thumbs');
}

if($this->profile->show_large_image == 1)
{
?>
	<div id="main_image_slideshow_wrapper<?php echo $this->uniqueid; ?>" class="main_image_slideshow_wrapper">
		
		<?php
		if($this->profile->show_slideshow_controls == 1 && $this->profile->slideshow_position == 'left-right')
		{
		?>
		<img src="<?php echo IG_IMAGE_ASSET_PATH; ?>left-side-arrow.png" id="slideshow_rewind<?php echo $this->uniqueid; ?>" alt="" style="float: left; padding-top: <?php echo $this->dimensions['largestHeight']/2 - 15; ?>px; padding-bottom:<?php echo $this->dimensions['largestHeight']/2 - 15; ?>px;"/>
		<?php
		}
		?>
		<div id="main_large_image<?php echo $this->uniqueid; ?>" class="main_large_image" style="width: <?php echo $this->dimensions['largestWidth']; ?>px; height: <?php echo $this->dimensions['largestHeight']; ?>px; ">
		</div>
		
		<?php
		if($this->profile->show_slideshow_controls == 1 && $this->profile->slideshow_position == 'left-right')
		{
		?>
		<img src="<?php echo IG_IMAGE_ASSET_PATH; ?>right-side-arrow.png" id="slideshow_forward<?php echo $this->uniqueid; ?>" alt="" style="float: left; padding-top: <?php echo $this->dimensions['largestHeight']/2 - 15; ?>px; padding-bottom:<?php echo $this->dimensions['largestHeight']/2 - 15; ?>px;"/>
		<?php
		}
		?>
		<div class="igallery_clear"></div>
	
	<?php
	if($this->profile->show_slideshow_controls == 1 && $this->profile->slideshow_position == 'below')
	{
	?>
		<div id="main_slideshow_buttons<?php echo $this->uniqueid; ?>" class="main_slideshow_buttons" >
			<img src="<?php echo IG_IMAGE_ASSET_PATH; ?>rewind.jpg" id="slideshow_rewind<?php echo $this->uniqueid; ?>" alt="" />
			<img src="<?php echo IG_IMAGE_ASSET_PATH; ?>play.jpg" id="slideshow_play<?php echo $this->uniqueid; ?>" alt="" />
			<img src="<?php echo IG_IMAGE_ASSET_PATH; ?>forward.jpg" id="slideshow_forward<?php echo $this->uniqueid; ?>" alt="" />
		</div>
	<?php
	}
	
	if($this->profile->show_numbering == 1)
	{
	   ?>
		<div id="main_img_numbering<?php echo $this->uniqueid; ?>" class="main_img_numbering">
			<span id="main_image_number<?php echo $this->uniqueid; ?>"></span>&#47;<?php echo count($this->photoList); ?>
		</div>
		<?php
	}

	if($this->profile->download_image != 'none')
	{
	?>
	   <div id="main_download_button<?php echo $this->uniqueid; ?>" class="main_download_button" >
	       <a href="#">
	           <img src="<?php echo IG_IMAGE_ASSET_PATH; ?>btn_download.png" alt="" />
	       </a>
	   </div>

	<?php
	}
	
	if($this->profile->share_facebook == 1)
	{
		?>
		<div id="main_facebook_share<?php echo $this->uniqueid; ?>" class="main_facebook_share">
			<iframe src="http://www.facebook.com/plugins/like.php?send=false&amp;layout=button_count&amp;width=70&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=21&amp;href=" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:70px; height:21px;" allowTransparency="true"></iframe>
		</div>
		<?php
	}
	
	if($this->profile->plus_one == 1)
	{
		?>
		<div id="main_plus_one_div<?php echo $this->uniqueid; ?>" class="main_plus_one_div">
			<div id="main_plus_one_button<?php echo $this->uniqueid; ?>" ></div>
		</div>
		
		<?php
	}
	
	if($this->profile->report_image == 1)
	{
	   ?>
		<div id="main_report<?php echo $this->uniqueid; ?>" class="main_report" >
	       <a href="#"><?php echo JText::_( 'REPORT_IMAGE' ) ?></a>
	       <form action="#" method="post" name="main_report_form" id="main_report_form" style="display: none;">
				<textarea name="report_textarea" id="main_report_textarea<?php echo $this->uniqueid; ?>" rows="4" style="width: 100%;"></textarea>
				<input name="Itemid" type="hidden" value="<?php echo JRequest::getInt('Itemid'); ?>" />
				<input type="submit" value="<?php echo JText::_( 'JSUBMIT' ) ?>" />
			</form>
	    </div>
	<?php
	}
	?>
	
	</div>
	<?php
}

if($this->profile->plus_one == 1 || $this->profile->lbox_plus_one == 1)
{
?>
	<script type="text/javascript" src="https://apis.google.com/js/plusone.js">
	  {parsetags: 'explicit'}
	</script>
<?php
}

if($this->profile->thumb_position == 'right' && $this->profile->show_thumbs == 1)
{
    $this->thumbsVars->thumb_container_width = $this->profile->thumb_container_width;
	$this->thumbsVars->thumb_container_height = $this->profile->thumb_container_height == 0 ? $this->dimensions['largestHeight'] : $this->profile->thumb_container_height;

	echo $this->loadTemplate('thumbs');
}

if($this->profile->photo_des_position == 'right' && $this->profile->show_descriptions == 1)
{
	$this->desVars->des_container_width = $this->profile->photo_des_width == 0 ? 200 : $this->profile->photo_des_width;
	$this->desVars->photo_des_height = $this->profile->photo_des_height == 0 ? $this->dimensions['largestHeight'] : $this->profile->photo_des_height;

	echo $this->loadTemplate('descriptions');
}

if($this->profile->photo_des_position == 'below' && $this->profile->show_descriptions == 1)
{
	$this->desVars->des_container_width = $this->profile->photo_des_width == 0 ? $this->dimensions['galleryWidth'] : $this->profile->photo_des_width;
	$this->desVars->photo_des_height = $this->profile->photo_des_height == 0 ? 50 : $this->profile->photo_des_height;

	echo $this->loadTemplate('descriptions');
}

if($this->profile->show_tags == 1)
{
	echo $this->loadTemplate('tags');
}


$this->ratingsVars = new stdClass();
$this->ratingsVars->prefix = 'main';

if($this->profile->allow_rating == 2)
{
	echo $this->loadTemplate('alratings');
}


if($this->profile->thumb_position == 'below' && $this->profile->show_thumbs == 1)
{
	$this->thumbsVars->thumb_container_width = $this->profile->thumb_container_width == 0 ? $this->dimensions['galleryWidth'] : $this->profile->thumb_container_width;
	$this->thumbsVars->thumb_container_height = $this->profile->thumb_container_height;

	echo $this->loadTemplate('thumbs');
}

$this->commentsVars = new stdClass();
$this->commentsVars->prefix = 'main';
$this->commentsVars->width = $this->dimensions['galleryWidth'];

if($this->profile->allow_comments == 4 || $this->profile->lbox_allow_comments == 4)
{
	?>
	<div id="fb-root"></div>
	<script>(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) {return;}
	  js = d.createElement(s); js.id = id;
	  js.src = "https://connect.facebook.net/en_US/all.js#xfbml=1&appId=<?php echo $this->params->get('fb_comments_appid', ''); ?>";
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));</script>
	<?php
}

if($this->profile->allow_comments == 4)
{
	echo $this->loadTemplate('fbcomments');
}

?>
</div>
<?php
}

if($this->profile->gallery_des_position == 'below' && strlen($this->category->gallery_description) > 1)
{
	echo $this->loadTemplate('category_description');
}

if($this->profile->lightbox == 1 && !empty($this->photoList) )
{
    echo $this->loadTemplate('lightbox');
}

?>
<div class="igallery_clear"></div>


