<?php defined('_JEXEC') or die('Restricted access'); ?>
	<div id="category_description<?php echo $this->uniqueid; ?>" class="category_description">
			<?php echo $this->category->gallery_description; ?>
	</div>
