<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
//this view is handled by the admin part of the component
//the files are here for Joomla's menu manager to read only