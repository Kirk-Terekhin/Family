<?php
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

class igViewcategories extends JView{}
//this view is handled by the admin part of the component 
//the files are here for Joomla's menu manager to read
?>