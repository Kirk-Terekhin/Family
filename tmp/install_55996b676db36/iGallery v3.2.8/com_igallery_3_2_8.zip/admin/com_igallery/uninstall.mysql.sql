DROP TABLE #__igallery;
DROP TABLE #__igallery_img;
DROP TABLE #__igallery_profiles;
