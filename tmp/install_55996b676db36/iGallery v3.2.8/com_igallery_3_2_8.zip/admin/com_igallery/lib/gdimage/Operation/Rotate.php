<?php
/**
* @version    $Id: Rotate.php 20 2010-09-23 07:16:05Z mthomsonnz $
* @package	  GDImage
* @copyright  2007-2010 Gasper Kozak, Matthew Thomson
* @license	  GNU Lesser General Public License version 2.1, see license.txt
*/

defined('JPATH_BASE') or die();

class GDImage_Operation_Rotate
{
	/**
	 * Returns rotated image
	 *
	 * @param GDImage_Image $image
	 * @param numeric $angle
	 * @param int $bgColor
	 * @param bool $ignoreTransparent
	 * @return GDImage_Image
	 */
	function execute($image, $angle, $bgColor, $ignoreTransparent)
	{
		$angle = -floatval($angle);
		if ($angle < 0)
			$angle = 360 + $angle;
		$angle = $angle % 360;
		
		if ($angle == 0)
			return $image->copy();
		
		$image = $image->asTrueColor();
		
		if ($bgColor === null)
		{
			$bgColor = $image->getTransparentColor();
			if ($bgColor == -1)
			{
				$bgColor = $image->allocateColorAlpha(255, 255, 255, 127);
				imagecolortransparent($image->getHandle(), $bgColor);
			}
		}
		return new GDImage_TrueColorImage(imagerotate($image->getHandle(), $angle, $bgColor, $ignoreTransparent));
	}
}
