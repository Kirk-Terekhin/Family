<?php
defined('_JEXEC') or die('Restricted access');

//define the paths used in php
define('IG_ADMINISTRATOR_COMPONENT', JPATH_ADMINISTRATOR.DS.'components'.DS.'com_igallery');
define( 'IG_IMAGE_PATH', JPATH_SITE.DS.'images'.DS.'igallery');
define( 'IG_TEMP_PATH', JPATH_SITE.DS.'images'.DS.'igallery'.DS.'temp');
define( 'IG_ORIG_PATH', JPATH_SITE.DS.'images'.DS.'igallery'.DS.'original');
define( 'IG_RESIZE_PATH', JPATH_SITE.DS.'images'.DS.'igallery'.DS.'resized');
define( 'IG_WATERMARK_PATH', JPATH_SITE.DS.'images'.DS.'igallery'.DS.'watermark');
define( 'IG_UPLOAD_PATH', IG_ADMINISTRATOR_COMPONENT.DS.'lib'.DS.'uploaders');
define( 'IG_COMPONENT', JPATH_SITE.DS.'components'.DS.'com_igallery'.DS);

//define the paths that will be outputted to the brower
define( 'IG_HOST', JURI::root() );
define( 'IG_IMAGE_HTML_RESIZE', JURI::root().'images/igallery/resized/');
define( 'IG_IMAGE_HTML_ORIG', JURI::root().'images/igallery/original/');
define( 'IG_IMAGE_HTML_WATERMARK', JURI::root().'images/igallery/watermark/');
define( 'IG_IMAGE_ASSET_PATH', JURI::root().'media/com_igallery/images/');

//import some classes
jimport('joomla.environment.uri' );
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

require_once(IG_ADMINISTRATOR_COMPONENT.DS.'helpers'.DS.'html.php');
require_once(IG_ADMINISTRATOR_COMPONENT.DS.'helpers'.DS.'file.php');
require_once(IG_ADMINISTRATOR_COMPONENT.DS.'helpers'.DS.'upload.php');
require_once(IG_ADMINISTRATOR_COMPONENT.DS.'helpers'.DS.'general.php');
require_once(IG_COMPONENT.DS.'helpers'.DS.'utility.php');
require_once(IG_ADMINISTRATOR_COMPONENT.DS.'models'.DS.'base.php');

//make the base folders if needed
igFileHelper::makeFolder(IG_IMAGE_PATH);
igFileHelper::makeFolder(IG_TEMP_PATH);
igFileHelper::makeFolder(IG_ORIG_PATH);
igFileHelper::makeFolder(IG_RESIZE_PATH);
igFileHelper::makeFolder(IG_WATERMARK_PATH);

?>