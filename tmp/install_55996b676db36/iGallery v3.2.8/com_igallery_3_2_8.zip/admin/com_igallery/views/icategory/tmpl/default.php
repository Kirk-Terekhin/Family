<?php defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.framework', true);
if($this->isSite == true)
{
	echo JToolBar::getInstance('toolbar')->render('toolbar');
}
?>
<script type="text/javascript">
var iToolbarIds = ['toolbar-apply','toolbar-save','toolbar-cancel'];
iToolbarIds.each(function(id, index)
{
	if( $chk( document.id(id) ) )
	{
		document.id(id).getElement('a').set('href', 'javascript: void(0)');
	}	
});	
</script>


<div style="clear: both"></div>
<form action="index.php?option=com_igallery" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
	<div class="width-60 fltlft">
		<fieldset class="adminform">
			<ul class="adminformlist">
			
			<li><?php echo $this->form->getLabel('name'); ?>
			<?php echo $this->form->getInput('name'); ?></li>
			
			<?php if( $this->isSite == false || $this->params->get('allow_frontend_cat_alias', 0) == 1): ?>
				<li><?php echo $this->form->getLabel('alias'); ?>
				<?php echo $this->form->getInput('alias'); ?></li>
			<?php endif; ?>
			
			<?php if( $this->isSite == false || $this->params->get('allow_frontend_cat_profile', 0) == 1): ?>
				<li><?php echo $this->form->getLabel('profile'); ?>
				<?php echo $this->form->getInput('profile'); ?></li>
			<?php endif; ?>
			
			<?php if( $this->isSite == false || $this->params->get('allow_frontend_cat_parent', 0) == 1): ?>	
				<li><?php echo $this->form->getLabel('parent'); ?>
				<?php echo $this->form->getInput('parent'); ?></li>
			<?php endif; ?>
			
			<?php if( $this->isSite == false || $this->params->get('allow_frontend_cat_image', 0) == 1): ?>	
				<li><?php echo $this->form->getLabel('upload_image'); ?>
			
				<?php if(!empty($this->item->menu_image_filename)): ?>
					    <img src="<?php echo IG_IMAGE_HTML_RESIZE; ?><?php echo $this->fileArray['folderName']; ?>/<?php echo $this->fileArray['fullFileName']; ?>" alt=""/>
				<?php endif; ?>
				
				<?php echo $this->form->getInput('upload_image'); ?>
				</li>
			<?php endif; ?>
				
			
			<?php if( $this->isSite == false || $this->params->get('allow_frontend_cat_remove', 0) == 1): ?>	
				<li><?php echo $this->form->getLabel('remove_menu_image'); ?>
				<?php echo $this->form->getInput('remove_menu_image'); ?></li>
			<?php endif; ?>
				
			<?php if($this->isSite == false): ?>
				<li><?php echo $this->form->getLabel('user'); ?>
				<?php echo $this->form->getInput('user'); ?></li>
			<?php endif; ?>
			
				
			<li><?php echo $this->form->getLabel('published'); ?>
			<?php echo $this->form->getInput('published'); ?></li>
			
				
			<?php if($this->isSite == false): ?>
				<li><?php echo $this->form->getLabel('publish_up'); ?>
					<?php echo $this->form->getInput('publish_up'); ?></li>
			
	
				<li><?php echo $this->form->getLabel('publish_down'); ?>
				<?php echo $this->form->getInput('publish_down'); ?></li>
			<?php endif; ?>
				
			<?php if( $this->isSite == false || $this->params->get('allow_frontend_cat_menu_des', 0) == 1): ?>	
				<?php echo $this->form->getLabel('menu_description'); ?>
				<div class="clr"></div>
				<?php echo $this->form->getInput('menu_description'); ?>
			<?php endif; ?>
			
			<?php if( $this->isSite == false || $this->params->get('allow_frontend_cat_gallery_des', 0) == 1): ?>	
				<?php echo $this->form->getLabel('gallery_description'); ?>
				<div class="clr"></div>
				<?php echo $this->form->getInput('gallery_description'); ?>
			<?php endif; ?>
				
			<li>
			<?php echo $this->form->getInput('id'); ?></li>
			</ul>

		</fieldset>
	</div>
	<div class="clr"></div>

	<input type="hidden" name="task" value="" />
	<?php if($this->isSite == true): ?>
	<input type="hidden" name="Itemid" value="<?php echo JRequest::getInt('Itemid', 0); ?>" />
	<?php endif; ?>
	<?php echo JHtml::_('form.token'); ?>
</form>