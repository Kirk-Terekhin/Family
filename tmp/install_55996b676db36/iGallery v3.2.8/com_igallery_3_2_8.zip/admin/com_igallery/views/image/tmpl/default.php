<?php defined('_JEXEC') or die();
JHTML::_('behavior.framework', true);
if($this->isSite == true)
{
	echo JToolBar::getInstance('toolbar')->render('toolbar');
}
?>

<script type="text/javascript">
var iToolbarIds = ['toolbar-apply','toolbar-save','toolbar-forward','toolbar-cancel'];
iToolbarIds.each(function(id, index)
{
	if( $chk( document.id(id) ) )
	{
		document.id(id).getElement('a').set('href', 'javascript: void(0)');
	}	
});	
</script>

<form action="<?php JRoute::_('index.php?option=com_igallery'); ?>" method="post" name="adminForm"  id="adminForm">
	<div class="width-60 fltlft">
		<fieldset class="adminform">
			
			<?php echo $this->form->getLabel('description'); ?>
			<div class="clr"></div>
			
			<?php echo $this->form->getInput('description'); ?>
			
			<ul class="adminformlist">
			
			<?php if( $this->isSite == false || $this->params->get('allow_frontend_photo_tags', 0) == 1): ?>
				<li><?php echo $this->form->getLabel('tags'); ?>
				<?php echo $this->form->getInput('tags'); ?>
			<?php endif; ?>
			
			<img src="<?php echo IG_IMAGE_HTML_RESIZE; ?><?php echo $this->thumbFile['folderName']; ?>/<?php echo $this->thumbFile['fullFileName']; ?>"
			width="<?php echo $this->thumbFile['width']; ?>" height="<?php echo $this->thumbFile['height'] ?>" alt="<?php echo $this->item->alt_text; ?>"/>
			</li>
			
			<?php if( $this->isSite == false || $this->params->get('allow_frontend_photo_alt', 0) == 1): ?>
				<li><?php echo $this->form->getLabel('alt_text'); ?>
				<?php echo $this->form->getInput('alt_text'); ?></li>
			<?php endif; ?>
			
			<?php if( $this->isSite == false || $this->params->get('allow_frontend_photo_link', 0) == 1): ?>	
				<li><?php echo $this->form->getLabel('link'); ?>
				<?php echo $this->form->getInput('link'); ?></li>
			<?php endif; ?>
			
			<?php if( $this->isSite == false || $this->params->get('allow_frontend_photo_window', 0) == 1): ?>	
				<li><?php echo $this->form->getLabel('target_blank'); ?>
				<?php echo $this->form->getInput('target_blank'); ?></li>
			<?php endif; ?>
			
			<?php if( $this->isSite == false || $this->params->get('allow_frontend_photo_access', 0) == 1): ?>	
			<li><?php echo $this->form->getLabel('access'); ?>
			<?php echo $this->form->getInput('access'); ?></li>
			<?php endif; ?>
			
			<?php if($this->isSite == false): ?>
			<li><?php echo $this->form->getLabel('user'); ?>
			<?php echo $this->form->getInput('user'); ?>
			</li>
			<?php endif; ?>
			
			<li><?php echo $this->form->getLabel('hits'); ?>
			<?php echo $this->form->getInput('hits'); ?>
			</li>
			
			<li><?php echo $this->form->getLabel('published'); ?>
			<?php echo $this->form->getInput('published'); ?></li>
			
			<?php if($this->isSite == false): ?>
			<li><?php echo $this->form->getLabel('publish_up'); ?>
				<?php echo $this->form->getInput('publish_up'); ?></li>

			<li><?php echo $this->form->getLabel('publish_down'); ?>
			<?php echo $this->form->getInput('publish_down'); ?></li>
			<?php endif; ?>
			
			</ul>
			<?php echo $this->form->getInput('id'); ?>
		</fieldset>
	</div>
	<div class="clr"></div>

	<input type="hidden" name="task" value="" />
	<?php if($this->isSite == true): ?>
	<input type="hidden" name="Itemid" value="<?php echo JRequest::getInt('Itemid', 0); ?>" />
	<?php endif; ?>
	<input type="hidden" name="catid" value="<?php echo $this->category->id; ?>" />
	<?php echo JHtml::_('form.token'); ?>
</form>