<?php
defined( '_JEXEC' ) or die('Restricted Access');

jimport( 'joomla.plugin.plugin' );

class plgSystemIgallery_img_inserter extends JPlugin {

	function __construct (&$subject, $params)
	{
		parent::__construct($subject, $params);
	}

    function onAfterDispatch()
    {
        $option =  JRequest::getCmd('option', '');
    
        if($option == 'com_search')
        {
            include(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_igallery'.DS.'defines.php');
            
            $db		  =& JFactory::getDBO();
    		$document =& JFactory::getDocument();
            $buffer   = $document->getBuffer('component');
            
            preg_match_all('/igalleryimg ([0-9]+?)/U', $buffer, $matches);
            
            $i=0;
            
            foreach($matches[1] as $imageId)
    	    {
    	        $query = ' SELECT '.
        		'#__igallery_img.filename, #__igallery_img.alt_text, #__igallery_img.gallery_id, #__igallery_img.ordering, #__igallery_img.rotation, '.
        		'#__igallery.profile, '.
        		'#__igallery_profiles.thumb_width, #__igallery_profiles.thumb_height, #__igallery_profiles.img_quality, #__igallery_profiles.crop_thumbs, #__igallery_profiles.round_thumb, #__igallery_profiles.round_fill, #__igallery_profiles.thumb_pagination, #__igallery_profiles.thumb_pagination_amount '.
            	' FROM #__igallery_img '.
            	' INNER JOIN #__igallery ON #__igallery_img.gallery_id = #__igallery.id '.
            	' INNER JOIN #__igallery_profiles ON #__igallery.profile = #__igallery_profiles.id '.
            	'WHERE #__igallery_img.id = '.(int)$imageId;
    	        
    	        $db->setQuery($query);
    	        $row = $db->loadObject();
    	        
    	        if(! $thumbFiles[$i] = igFileHelper::originalToResized($row->filename, $row->thumb_width, 
    		    $row->thumb_height, $row->img_quality, $row->crop_thumbs, $row->rotation, $row->round_thumb, $row->round_fill) )
    		    {
    		    	JError::raise(2, 500, 'img inserter makeimage error');
    		        return false;
    		    }
				
				$limitStart = '';
				if($row->thumb_pagination == 1)
				{
					if($row->ordering > $row->thumb_pagination_amount)
					{
						$group = ceil( $row->ordering / $row->thumb_pagination_amount ) - 1;
						
						if($group > 0)
						{
							$limitStart = '&limitstart='.($group * $row->thumb_pagination_amount);
							$remainder = $row->ordering - ($group * $row->thumb_pagination_amount);
							$row->ordering = $remainder == 0 ? 1 : $remainder;
						}
					}
				}
    		    
    		    $link = JRoute::_('index.php?option=com_igallery&view=category&igid='.$row->gallery_id.'&image='.$row->ordering.'&Itemid='.igUtilityHelper::getItemid($row->gallery_id).$limitStart);
    		
    	        $imageTag = '<a href="'.$link.'"><img src="'.IG_IMAGE_HTML_RESIZE.$thumbFiles[$i]['folderName'].'/'.$thumbFiles[$i]['fullFileName'].'" 
			    width="'.$thumbFiles[$i]['width'].'" height="'.$thumbFiles[$i]['height'].'" alt="'.$row->alt_text.'"/></a>';
    	        
    	        $buffer = str_replace("igalleryimg $imageId ", $imageTag, $buffer);
    	        
    	        $i++;
    	    }
            
            $document->setBuffer($buffer, 'component');
        }
    }
}
