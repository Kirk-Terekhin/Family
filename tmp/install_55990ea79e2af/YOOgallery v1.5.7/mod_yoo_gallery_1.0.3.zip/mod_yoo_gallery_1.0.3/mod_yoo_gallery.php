<?php
/**
* YOOgallery Joomla! Module
*
* @author    yootheme.com
* @copyright Copyright (C) 2008 YOOtheme. All rights reserved.
* @license	 GNU/GPL
*/

// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

global $mosConfig_live_site, $mosConfig_absolute_path;

if (!class_exists('YOOGallery')) {
	require_once(dirname(__FILE__).'/mod_yoo_gallery/yoo_gallery/gallery.php');
}

// set gallery params
$params->set('cfg_path', 'modules/mod_yoo_gallery/yoo_gallery/');
$params->set('cfg_juri', $mosConfig_live_site.'/');
$params->set('cfg_jroot', $mosConfig_absolute_path);

// render gallery
$gallery =& new YOOGallery($params);
echo $gallery->render();