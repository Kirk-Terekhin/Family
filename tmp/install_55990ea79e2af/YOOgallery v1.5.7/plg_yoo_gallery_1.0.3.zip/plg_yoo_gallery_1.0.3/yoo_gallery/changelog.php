<?php
/**
* YOOgallery Joomla! Plugin
*
* @author    yootheme.com
* @copyright Copyright (C) 2008 YOOtheme. All rights reserved.
* @license	 GNU/GPL
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

Changelog
------------

1.0.3
+ Added disable thumb re-caching (set cache time to -1)
# Fixed sorting to use filename instead of title

1.0.2
+ Added smart image resizing
+ Added thumbnail count option
# Fixed rarely appearing image borders in Non-YOOtheme templates

1.0.1
+ Added PHP GD image processing lib check
+ Added smooth image resampling
+ Added thumbnail resize option
+ Added custom lightbox rel parameter
+ Added thumbnail ordering option

1.0.0
- Initial Release



* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note