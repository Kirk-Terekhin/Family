<?php
/**
* YOOgallery Joomla! Plugin
*
* @author    yootheme.com
* @copyright Copyright (C) 2007 YOOtheme. All rights reserved.
* @license	 GNU/GPL
*/

// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

$_MAMBOTS->registerFunction( 'onPrepareContent', 'plgContentYOOgallery' );

if (!class_exists('YOOGallery')) {
	require_once(dirname(__FILE__).'/yoo_gallery/gallery.php');
}

/**
* Plugin that creates YOOgallery within content
*/
function plgContentYOOgallery( $published, &$row, &$params, $page=0 ) {
	global $mainframe, $database, $mosConfig_live_site, $_MAMBOTS;
	
	// simple performance check to determine whether bot should process further
	if (strpos($row->text, 'yoogallery') === false) {
		return true;
	}

 	// expression to search for
	$regex = "#{yoogallery\s*(.*?)}#s";

	// check whether plugin has been unpublished
	if (!$published) {
		$row->text = preg_replace($regex, '', $row->text);
		return true;
	}	

	// perform the replacement
	preg_match_all($regex, $row->text, $matches);
 	$count = count($matches[0]);

 	if ($count) {
		// check if param query has previously been processed
		if (!isset($_MAMBOTS->_content_mambot_params['yoo_gallery'])) {
			// load mambot params info
			$query = "SELECT params"
			. "\n FROM #__mambots"
			. "\n WHERE element = 'yoo_gallery'"
			. "\n AND folder = 'content'";
			$database->setQuery($query);
			$database->loadObject($mambot);

			// save query to class variable
			$_MAMBOTS->_content_mambot_params['yoo_gallery'] = $mambot;
		}

		// pull query data from class variable
		$mambot = $_MAMBOTS->_content_mambot_params['yoo_gallery'];
	 	$pluginParams = new mosParameters( $mambot->params );
	
 		plgContentYOOgalleryReplace($row, $matches, $count, $regex, $pluginParams);
	}
}

function plgContentYOOgalleryReplace(&$row, &$matches, $count, $regex, $pluginParams) {
	global $mosConfig_live_site, $mosConfig_absolute_path;

	for ($i = 0; $i < $count; $i++) {

		// set line params
		$parameter = plgContentYOOgalleryGetParams($matches[1][$i], array('width' => null, 'height' => null));

		// set default thumbnail size, if no sizes defined
		if (!$parameter['width'] && !$parameter['height']) {
			$parameter['width']  = $pluginParams->get('width', 100);
			$parameter['height'] = null;
		}

		// set gallery params
		$params = new mosParameters('');
		foreach ($pluginParams->toArray() as $key => $val) $params->set($key, $val);
		foreach ($parameter as $key => $val) $params->set($key, $val);
		$params->set('cfg_path', 'mambots/content/yoo_gallery/');
		$params->set('cfg_juri', $mosConfig_live_site.'/');
		$params->set('cfg_jroot', $mosConfig_absolute_path);

		// render gallery
		$gallery =& new YOOGallery($params);
		$replace =  $gallery->render();

		// replace
		$row->text = str_replace($matches[0][$i], $replace, $row->text);
 	}
}

function plgContentYOOgalleryGetParams($param_line, $default = array()) {
	$matches = array();
	$parameter = $default;
	
	preg_match_all("#(\w+)=\[(.*?)\]#s", $param_line, $matches);
    for ($i = 0; $i < count($matches[1]); $i++) {
		$parameter[strtolower($matches[1][$i])] = $matches[2][$i];
    }
	
	return $parameter;
}