<?php
/**
* YOOgallery Joomla! Module
*
* @author    yootheme.com
* @copyright Copyright (C) 2008 YOOtheme. All rights reserved.
* @license	 GNU/GPL
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

Changelog
------------

1.5.7
# Mootools 1.2 compatibility upgrade

1.5.6
# Fixed cut style

1.5.5
# Fixed PHP 5.3 compatibility

1.5.4
+ Added disable thumb re-caching (set cache time to -1)
# Fixed sorting to use filename instead of title

1.5.3
^ Changed black styling CSS selector

1.5.2
+ Added smart image resizing
+ Added thumbnail count option
# Fixed rarely appearing image borders in Non-YOOtheme templates

1.5.1
+ Added PHP GD image processing lib check
+ Added smooth image resampling
+ Added thumbnail resize option
+ Added custom lightbox rel parameter
+ Added thumbnail ordering option

1.5.0
- Initial Release



* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note