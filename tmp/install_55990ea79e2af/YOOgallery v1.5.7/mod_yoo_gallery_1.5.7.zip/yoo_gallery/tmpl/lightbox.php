<?php
/**
* YOOgallery Core
*
* @author    yootheme.com
* @copyright Copyright (C) 2008 YOOtheme. All rights reserved.
* @license	 GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

// add javascript and css
if ($load_lightbox && $this->includeOnce('YOO_GALLERY_LIGHTBOX')) {
	// add javascript and css
	if (JPluginHelper::isEnabled('system', 'mtupgrade')) {
		JHTML::script('slimbox_packed.js', $this->uri.'lib/lightbox/');
		JHTML::stylesheet('slimbox.css', $this->uri.'lib/lightbox/css/');
	} else {
		JHTML::script('slimbox_packed.js', $this->uri.'lib/mootools_old/lightbox/');
		JHTML::stylesheet('slimbox.css', $this->uri.'lib/mootools_old/lightbox/css/');
	}
}

// add spotlight javascript
if ($spotlight && $this->includeOnce('YOO_GALLERY_JS')) JHTML::script('gallery.js', $this->uri);

// init vars
$a_attribs = ($rel != '') ? 'rel="'.$rel.'"' : 'rel="lightbox['.$gallery_id.']"';

?>
<div class="<?php echo $style.' '.$thumb_style; ?>">
	<div id="<?php echo $gallery_id; ?>" class="yoo-gallery <?php echo $style; ?>">
	
		<div class="thumbnails">
		<?php 
			for ($j=0; $j < count($thumbs); $j++) :
				$thumb = $thumbs[$j];
				include($tmpl_thumb);
 			endfor;
		?>
		</div>
		
	</div>
</div>
<?php if ($spotlight) : ?>
<script type="text/javascript">
	window.addEvent('domready', function(){
		var fx = new YOOgalleryfx('<?php echo $gallery_id; ?>');
	});
</script>
<?php endif; ?>